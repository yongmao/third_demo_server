const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();
const _ = db.command;

exports.main = async (event, context) => {
  try{
    let FAS = await db.collection('INFO').doc('base_info').get();
    await db.collection('INFO').doc('base_info').update({
      data:{
        see:_.inc(1)
      }
    });
    return FAS.data;
  }
  catch(e){
    return {
      _id:null
    };
  }
}